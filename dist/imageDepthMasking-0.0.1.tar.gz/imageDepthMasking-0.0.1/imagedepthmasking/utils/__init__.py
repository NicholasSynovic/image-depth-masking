"""
Utility functions for the larger application
"""
